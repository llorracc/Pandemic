This folder contains pickled output from the script GiveItAwayVoila.py in
./Code/Python.  These files are used by our interactive web dashboard to
display figures and aren't of much use to humans.